import discord
from discord.ext import commands
import os
from PIL import Image, ImageFont, ImageDraw
import shutil
import os
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import datetime
import pandas as pd
import sys
import openpyxl
import datetime
from datetime import datetime

class Yaz(commands.Cog):
  
  def __init__(self,bot):
    self.bot=bot
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def embed(self,ctx,*,metin):
    if metin == None:
      await ctx.send("Lütfen Birşeyler Yazınız")
    await ctx.message.delete()
    embed=discord.Embed(description=f"{metin}",colour=discord.Colour.red())
    embed.set_author(name=str(self.bot.user.name),icon_url=self.bot.user.avatar_url)
    await ctx.send(embed=embed)
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def mesaj(self,ctx,*,metin):
    if metin == None:
      await ctx.send("Lütfen Birşeyler Yazınız")
    for attachment in ctx.message.attachments:
      b = str(ctx.message.attachments)
      adim1 = b.split("filename='")[1].split("'")[0]
      adim2 = adim1.split(f".")[1]
      await attachment.save(f"./text_gelen.{adim2}")
      await ctx.message.delete()
      await ctx.send(str(metin),file=discord.File(f"./text_gelen.{adim2}"))
      os.remove(f"./text_gelen.{adim2}")
      break
    else:
      await ctx.message.delete()
      await ctx.send(str(metin))
  
  
  @commands.command()
  @commands.has_any_role("Bot Kullanım")
  async def otomesajgönder(self,ctx,role: discord.Role,*,mesaj: str = None):
    if mesaj == None:
      return await ctx.send("Lütfen Bir Mesaj Giriniz")
    sayi = 0
    sayisiz = 0
    for member in role.members:
      try:
        await member.send(f"{mesaj}")
      except:
        await ctx.send(f"{member.name}#{member.discriminator} Kişisine Mesaj Gönderilemedi")
        sayisiz += 1
      sayi += 1
    if sayisiz != 0:
      await ctx.send(f"{sayi} Kişiye Belirtilen Mesajı İlettim Ama {sayisiz} Kişiye Direkt Mesajlar Özelliği Kapalı Olduğu İçin İletemedim")
    else:
      await ctx.send(f"{sayi} Kişiye Belirtilen Mesajı İlettim")
    
    
  
def setup(bot):
  bot.add_cog(Yaz(bot))