import discord
from discord.ext import commands

class Ban(commands.Cog):
  
  def __init__(self,bot):
    self.bot=bot
  
  @commands.command(aliases=["Ban","BAN"])
  @commands.has_permissions(ban_members=True)
  async def ban(self,ctx,kisi:discord.Member,*,reason="Sebep Girilmedi"):
    if kisi.id == ctx.author.id:
      await ctx.send("Kendini Banlayamazsın")
    else:
      await kisi.ban(reason=reason)
      await ctx.send(f"{kisi.name}#{kisi.discriminator} Kişisi Sunucudan Uzaklaştırıldı Sebep: {reason}")
  
  @ban.error
  async def ban_error(self,ctx,error):
    if isinstance(error,commands.MissingPermissions):
      await ctx.send(f"{ctx.author.mention} Bu Komudu Kullanabilmen İçin **Üyeleri Banlama** Yetkisine Sahip Olmanız Gerekiyor")
      
  @commands.command(aliases=["UNBAN","Unban"])
  @commands.has_permissions(ban_members=True)
  async def unban(self,ctx,*,kisi):
    banlilar = await ctx.guild.bans()
    
    kisi_adi,kisi_discriminator=kisi.split("#")
    
    for ban in banlilar:
      user=ban.user
      
      if (user.name,user.discriminator) == (kisi_adi,kisi_discriminator):
        await ctx.guild.unban(user)
        await ctx.send(f"{user.name}#{user.discriminator} Adlı Kişinin Banı Kaldırıldı")
        
  @unban.error
  async def unban_error(self,ctx,error):
    if isinstance(error,commands.MissingPermissions):
      await ctx.send(f"{ctx.author.mention} Bu Komudu Kullanabilmen İçin **Üyelerin Yasağını Kaldırmak** Yetkisine Sahip Olmanız Gerekiyor")
  
def setup(bot):
  bot.add_cog(Ban(bot))