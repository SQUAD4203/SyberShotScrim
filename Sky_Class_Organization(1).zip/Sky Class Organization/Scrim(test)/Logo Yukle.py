# encoding:utf-8
import discord
from discord.ext import commands
import shutil
import uuid
import pathlib
import os
import requests
import sys


class Logo_Yukle(commands.Cog):
  def __init__(self,bot):
    self.bot=bot
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def logoyukle(self,ctx,*,takim_adi):
    def check(m):
      return m.author.id==ctx.author.id
    for attachment in ctx.message.attachments:
      b = str(ctx.message.attachments)
      adim1 = b.split("filename='")[1].split("'")[0]
      adim2 = adim1.split(f".")[1]
      if str(adim2.lower()) != "png":
        return await ctx.send("Lütfen Yükleyeceğiniz Logoyu Png Formatında Yükleyiniz")
      else:
        path=pathlib.Path(f"./Logolar/{takim_adi}.png")
        if path.exists():
          await ctx.send("Bu Takıma Ait Logo Daha Önce Yüklemiştir Eski Logo İle Değiştirmemi İstiyorsan Evet Yazman Yeterli")
          m = await self.bot.wait_for("message",check=check)
          if m.content.lower() == "evet":
            await attachment.save(f"./Logolar/{takim_adi}.png")
            await ctx.send("Logo Değiştirilmiştir")
            break
          else:
            await ctx.send("Hatalı Kullanım Lütfen Tekrar Deneyiniz")
            break
        else:
          await attachment.save(f"./Logolar/{takim_adi}.png")
          await ctx.send("Logo Yüklendi")
          break
    else:
      await ctx.send("Yüklenecek Hiç Logo Bulunamadı Yoksa Logoyu Yüklemeyi Mi Unuttun?")
     # if url[0:26] == "https://cdn.discordapp.com":
     #   r=requests.get(url)
      #  image=str(mesajlo.content)+".jpg"
       # with open(f"./Logolar/{image}","wb") as file:
      #    shutil.copyfileobj(r.raw,file)
      #  await ctx.send("Logonuz Yüklenmiştir")"""

  @commands.command()
  async def logo_cagir(self,ctx,*,takim):
    await ctx.send(file=discord.File(f"./Logolar/{takim}.png"))
      
    
def setup(bot):
  bot.add_cog(Logo_Yukle(bot))