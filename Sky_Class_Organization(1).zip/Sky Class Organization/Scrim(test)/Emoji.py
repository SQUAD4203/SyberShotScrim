import discord
from discord.ext import commands


class Emoji_Gonder(commands.Cog):
    def __init__(self,bot):
        self.bot = bot

    @commands.has_permissions(administrator=True)
    @commands.command()
    async def emoji_gonder(self,ctx,*,emoji_adi):
        emoji = discord.utils.get(self.bot.emojis, name=str(emoji_adi))
        await ctx.send("İstrdiğin Emoji: "+str(emoji))


def setup(bot):
    bot.add_cog(Emoji_Gonder(bot))