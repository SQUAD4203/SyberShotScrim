# encoding:utf-8
from tabnanny import check
import discord
import openpyxl
from discord.ext import commands
from PIL import Image, ImageFont, ImageDraw
import os
import time
import shutil
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import datetime
import pandas as pd
import sys


class Sky_Olustur(commands.Cog):
  def __init__(self,bot):
    self.bot=bot

  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def sky_slot(self,ctx):
    channel_id=821206671535916747
    def checks(m):
      return m.author.id==ctx.author.id

    shutil.copy("./Sky Slot Tablosu.png", "./Scrim(test)/Sky Slot 1.png")
    await ctx.send("Lütfen Takımları Giriniz")
    msg =  await self.bot.wait_for("message",check=checks)
    sayi=0
    message = msg.content.split("\n")
    
    scope = ["https://spreadsheets.google.com/feeds",'https://www.googleapis.com/auth/spreadsheets',"https://www.googleapis.com/auth/drive.file","https://www.googleapis.com/auth/drive"]
    
    cred=ServiceAccountCredentials.from_json_keyfile_name("./Scrim(test)/bilgiler.json",scope)
    
    login=gspread.authorize(cred)
    
    sh1=login.open("Sky Organization Sky Series").worksheet("Sayfa1")
    
    
    range_of_cells = sh1.range('A3:U29')
    for cell in range_of_cells:
      cell.value = ''
    sh1.update_cells(range_of_cells)
     
    '''sh1["A3"].value=None
    sh1["A4"].value=None
    sh1["A5"].value=None
    sh1["A6"].value=None
    sh1["A7"].value=None
    sh1["A8"].value=None
    sh1["A9"].value=None
    sh1["A10"].value=None
    sh1["A11"].value=None
    sh1["A12"].value=None
    sh1["A13"].value=None
    sh1["A14"].value=None
    sh1["A15"].value=None
    sh1["A16"].value=None
    sh1["A17"].value=None
    sh1["A18"].value=None
    sh1["A19"].value=None
    sh1["A20"].value=None
     
    sh1["B3"].value=None
    sh1["C3"].value=None
    sh1["D3"].value=None
    sh1["E3"].value=None
    sh1["F3"].value=None
    sh1["G3"].value=None
    sh1["H3"].value=None
    sh1["I3"].value=None
    sh1["J3"].value=None
    sh1["K3"].value=None
     
    sh1["B4"].value=None
    sh1["C4"].value=None
    sh1["D4"].value=None
    sh1["E4"].value=None
    sh1["F4"].value=None
    sh1["G4"].value=None
    sh1["H4"].value=None
    sh1["I4"].value=None
    sh1["J4"].value=None
    sh1["K4"].value=None
     
    sh1["B5"].value=None
    sh1["C5"].value=None
    sh1["D5"].value=None
    sh1["E5"].value=None
    sh1["F5"].value=None
    sh1["G5"].value=None
    sh1["H5"].value=None
    sh1["I5"].value=None
    sh1["J5"].value=None
    sh1["K5"].value=None
     
    sh1["B6"].value=None
    sh1["C6"].value=None
    sh1["D6"].value=None
    sh1["E6"].value=None
    sh1["F6"].value=None
    sh1["G6"].value=None
    sh1["H6"].value=None
    sh1["I6"].value=None
    sh1["J6"].value=None
    sh1["K6"].value=None
      
    sh1["B7"].value=None
    sh1["C7"].value=None
    sh1["D7"].value=None
    sh1["E7"].value=None
    sh1["F7"].value=None
    sh1["G7"].value=None
    sh1["H7"].value=None
    sh1["I7"].value=None
    sh1["J7"].value=None
    sh1["K7"].value=None
      
    sh1["B8"].value=None
    sh1["C8"].value=None
    sh1["D8"].value=None
    sh1["E8"].value=None
    sh1["F8"].value=None
    sh1["G8"].value=None
    sh1["H8"].value=None
    sh1["I8"].value=None
    sh1["J8"].value=None
    sh1["K8"].value=None
   
    sh1["B9"].value=None
    sh1["C9"].value=None
    sh1["D9"].value=None
    sh1["E9"].value=None
    sh1["F9"].value=None
    sh1["G9"].value=None
    sh1["H9"].value=None
    sh1["I9"].value=None
    sh1["J9"].value=None
    sh1["K9"].value=None
   
    sh1["B10"].value=None
    sh1["C10"].value=None
    sh1["D10"].value=None
    sh1["E10"].value=None
    sh1["F10"].value=None
    sh1["G10"].value=None
    sh1["H10"].value=None
    sh1["I10"].value=None
    sh1["J10"].value=None
    sh1["K10"].value=None
   
    sh1["B11"].value=None
    sh1["C11"].value=None
    sh1["D11"].value=None
    sh1["E11"].value=None
    sh1["F11"].value=None
    sh1["G11"].value=None
    sh1["H11"].value=None
    sh1["I11"].value=None
    sh1["J11"].value=None
    sh1["K11"].value=None
   
    sh1["B12"].value=None
    sh1["C12"].value=None
    sh1["D12"].value=None
    sh1["E12"].value=None
    sh1["F12"].value=None
    sh1["G12"].value=None
    sh1["H12"].value=None
    sh1["I12"].value=None
    sh1["J12"].value=None
    sh1["K12"].value=None
   
    sh1["B13"].value=None
    sh1["C13"].value=None
    sh1["D13"].value=None
    sh1["E13"].value=None
    sh1["F13"].value=None
    sh1["G13"].value=None
    sh1["H13"].value=None
    sh1["I13"].value=None
    sh1["J13"].value=None
    sh1["K13"].value=None
   
    sh1["B14"].value=None
    sh1["C14"].value=None
    sh1["D14"].value=None
    sh1["E14"].value=None
    sh1["F14"].value=None
    sh1["G10"].value=None
    sh1["H14"].value=None
    sh1["I14"].value=None
    sh1["J14"].value=None
    sh1["K14"].value=None
   
    sh1["B15"].value=None
    sh1["C15"].value=None
    sh1["D15"].value=None
    sh1["E15"].value=None
    sh1["F15"].value=None
    sh1["G15"].value=None
    sh1["H15"].value=None
    sh1["I15"].value=None
    sh1["J15"].value=None
    sh1["K15"].value=None
   
    sh1["B16"].value=None
    sh1["C16"].value=None
    sh1["D16"].value=None
    sh1["E16"].value=None
    sh1["F16"].value=None
    sh1["G16"].value=None
    sh1["H16"].value=None
    sh1["I16"].value=None
    sh1["J16"].value=None
    sh1["K16"].value=None
     
    sh1["B17"].value=None
    sh1["C17"].value=None
    sh1["D17"].value=None
    sh1["E17"].value=None
    sh1["F17"].value=None
    sh1["G17"].value=None
    sh1["H17"].value=None
    sh1["I17"].value=None
    sh1["J17"].value=None
    sh1["K17"].value=None
     
     
    sh1["B18"].value=None
    sh1["C18"].value=None
    sh1["D18"].value=None
    sh1["E18"].value=None
    sh1["F18"].value=None
    sh1["G18"].value=None
    sh1["H18"].value=None
    sh1["I18"].value=None
    sh1["J18"].value=None
    sh1["K18"].value=None
      
    sh1["B19"].value=None
    sh1["C19"].value=None
    sh1["D19"].value=None
    sh1["E19"].value=None
    sh1["F19"].value=None
    sh1["G19"].value=None
    sh1["H19"].value=None
    sh1["I19"].value=None
    sh1["J19"].value=None
    sh1["K19"].value=None
   
    sh1["B20"].value=None
    sh1["C20"].value=None
    sh1["D20"].value=None
    sh1["E20"].value=None
    sh1["F20"].value=None
    sh1["G20"].value=None
    sh1["H20"].value=None
    sh1["I20"].value=None
    sh1["J20"].value=None
    sh1["K20"].value=None'''
   
   
   # 
    takim1=sh1.update_cell(3,1,message[0])

    takim2=sh1.update_cell(4,1,message[1])
    
    takim3=sh1.update_cell(5,1,message[2])
    
    takim4=sh1.update_cell(6,1,message[3])
    
    takim5=sh1.update_cell(7,1,message[4])

    try:
      takim6=sh1.update_cell(8,1,message[5])
    except:
      pass
    try:
      takim7=sh1.update_cell(9,1,message[6])
    except:
      pass
    try:
      takim8=sh1.update_cell(10,1,message[7])
    except:
      pass
    try:
      takim9=sh1.update_cell(11,1,message[8])
    except:
      pass
    try:
      takim10=sh1.update_cell(12,1,message[9])
    except:
      pass
    try:
      takim11=sh1.update_cell(13,1,message[10])
    except:
      pass
    try:
      takim12=sh1.update_cell(14,1,message[11])
    except:
      pass
    try:
      takim13=sh1.update_cell(15,1,message[12])
    except:
      pass
    try:
      takim14=sh1.update_cell(16,1,message[13])
    except:
      pass
    try:
      takim15=sh1.update_cell(17,1,message[14])
    except:
      pass
    try:
      takim16=sh1.update_cell(18,1,message[15])
    except:
      pass
    try:
      takim17=sh1.update_cell(19,1,message[16])
    except:
      pass
    try:
      takim18=sh1.update_cell(20,1,message[17])
    except:
      pass
    try:
      takim19=sh1.update_cell(21,1,message[18])
    except:
      pass
    try:
      takim20=sh1.update_cell(22,1,message[19])
    except:
      pass
    try:
      takim21=sh1.update_cell(23,1,message[20])
    except:
      pass
    try:
      takim22=sh1.update_cell(24,1,message[21])
    except:
      pass
    try:
      takim23=sh1.update_cell(25,1,message[22])
    except:
      pass
    try:
      takim24=sh1.update_cell(26,1,message[23])
    except:
      pass
    try:
      takim25=sh1.update_cell(27,1,message[24])
    except:
      pass
    try:
      takim26=sh1.update_cell(28,1,message[25])
    except:
      pass
    try:
      takim27=sh1.update_cell(29,1,message[26])
    except:
      pass
    takim11=sh1.cell(3,1).value
    takim22=sh1.cell(4,1).value
    takim33=sh1.cell(5,1).value
    takim44=sh1.cell(6,1).value
    takim55=sh1.cell(7,1).value
    takim66=sh1.cell(8,1).value
    takim77=sh1.cell(9,1).value
    takim88=sh1.cell(10,1).value
    takim99=sh1.cell(11,1).value
    takim100=sh1.cell(12,1).value
    takim110=sh1.cell(13,1).value
    takim120=sh1.cell(14,1).value
    takim130=sh1.cell(15,1).value
    takim140=sh1.cell(16,1).value
    takim150=sh1.cell(17,1).value
    takim160=sh1.cell(18,1).value
    takim170=sh1.cell(19,1).value
    takim180=sh1.cell(20,1).value
    takim190=sh1.cell(21,1).value
    takim200=sh1.cell(22,1).value

    
    result_olucak = "Sky"

    if result_olucak == "Sky":
      result=Image.open("./Scrim(test)/Sky Slot 1.png")
      draw=ImageDraw.Draw(result)
      font=ImageFont.truetype("Scrim(test)/American Captain.otf",50)

      slot1=draw.text((467,300), str(takim11), fill="black", font=font)
      slot2=draw.text((467,358), str(takim22), fill="black", font=font)
      slot3=draw.text((467,416), str(takim33), fill="black", font=font)
      slot4=draw.text((467,476), str(takim44), fill="black", font=font)
      slot5=draw.text((467,535), str(takim55), fill="black", font=font)
      if takim66 != None:
        slot6=draw.text((467,595), str(takim66), fill="black", font=font)
      if takim77 != None:
        slot7=draw.text((467,655), str(takim77), fill="black", font=font)
      if takim88 != None:
        slot8=draw.text((467,713), str(takim88), fill="black", font=font)
      if takim99 != None:
        slot9=draw.text((467,773), str(takim99), fill="black", font=font)
      if takim100 != None:
        slot10=draw.text((467,832), str(takim100), fill="black", font=font)
      if takim110 != None:
        slot11=draw.text((1212,300), str(takim110), fill="black", font=font)
      if takim120 != None:
        slot12=draw.text((1212,358), str(takim120), fill="black", font=font)
      if takim130 != None:
        slot13=draw.text((1212,416), str(takim130), fill="black", font=font)
      if takim140 != None:
        slot14=draw.text((1212,476), str(takim140), fill="black", font=font)
      if takim150 != None:
        slot15=draw.text((1212,535), str(takim150), fill="black", font=font)
      if takim160 != None:
        slot16=draw.text((1212,595), str(takim160), fill="black", font=font)
      if takim170 != None:
        slot17=draw.text((1212,655), str(takim170), fill="black", font=font)
      if takim180 != None:
        slot18=draw.text((1212,713), str(takim180), fill="black", font=font)
      if takim190 != None:
        slot19=draw.text((1212,773), str(takim190), fill="black", font=font)
      if takim200 != None:
        slot20=draw.text((1212,832), str(takim200), fill="black", font=font)

      klasorr=os.listdir("./Logolar/")

      aldi=True
      try:
          data1=Image.open(f"./Logolar/{takim11}.png")
      except:
            aldi=False
      if aldi:
            data11 = data1.resize((45, 45))
            rgba = data11.convert("RGBA")
            x = result.size[0]//2
            y = result.size[1]//2

            result = Image.alpha_composite(
                Image.new("RGBA", result.size),
                result.convert('RGBA')
            )

            result.paste(
                data11,
                (408, 296),
                data11
            )
      
      aldi=True
      try:
          data2=Image.open(f"./Logolar/{takim22}.png")
      except:
            aldi=False
      if aldi:
            data22 = data2.resize((45, 45))
            rgba = data22.convert("RGBA")
            x = result.size[0]//2
            y = result.size[1]//2

            result = Image.alpha_composite(
                Image.new("RGBA", result.size),
                result.convert('RGBA')
            )

            result.paste(
                data22,
                (408, 358),
                data22
            )
      

      aldi=True
      try:
          data3=Image.open(f"./Logolar/{takim33}.png")
      except:
          aldi=False
      if aldi:
        data33 = data3.resize((45, 45))
        rgba = data33.convert("RGBA")
        x = result.size[0]//2
        y = result.size[1]//2

        result = Image.alpha_composite(
          Image.new("RGBA", result.size),
          result.convert('RGBA')
        )

        result.paste(
          data33,
          (408, 416),
          data33
        )

      aldi=True
      try:
          data4=Image.open(f"./Logolar/{takim44}.png")
      except:
          aldi=False
      if aldi:
        data44 = data4.resize((45, 45))
        rgba = data44.convert("RGBA")
        x = result.size[0]//2
        y = result.size[1]//2

        result = Image.alpha_composite(
          Image.new("RGBA", result.size),
          result.convert('RGBA')
        )

        result.paste(
          data44,
          (408, 476),
          data44
        )
      
      
      aldi=True
      try:
          data5=Image.open(f"./Logolar/{takim55}.png")
      except:
          aldi=False
      if aldi:
        data55 = data5.resize((45, 45))
        rgba = data55.convert("RGBA")
        x = result.size[0]//2
        y = result.size[1]//2

        result = Image.alpha_composite(
        Image.new("RGBA", result.size),
        result.convert('RGBA')
        )

        result.paste(
          data55,
          (408, 535),
          data55
        )
        
      if takim66 != None:
        aldi=True
        try:
          data6=Image.open(f"./Logolar/{takim66}.png")
        except:
          aldi=False
        if aldi:
          data66 = data6.resize((45, 45))
          rgba = data66.convert("RGBA")
          x = result.size[0]//2
          y = result.size[1]//2

          result = Image.alpha_composite(
              Image.new("RGBA", result.size),
              result.convert('RGBA')
          )

          result.paste(
            data66,
            (408,595),
            data66
          )
          
      if takim77 != None:
        aldi=True
        try:
          data7=Image.open(f"./Logolar/{takim77}.png")
        except:
          aldi=False
        if aldi:
          data77 = data7.resize((45, 45))
          rgba = data77.convert("RGBA")
          x = result.size[0]//2
          y = result.size[1]//2

          result = Image.alpha_composite(
            Image.new("RGBA", result.size),
            result.convert('RGBA')
          )

          result.paste(
            data77,
            (408,651),
            data77
          )
          
      if takim88 != None:
        aldi=True
        try:
          data8=Image.open(f"./Logolar/{takim88}.png")
        except:
          aldi=False
        if aldi:
          data88 = data8.resize((45, 45))
          rgba = data88.convert("RGBA")
          x = result.size[0]//2
          y = result.size[1]//2

          result = Image.alpha_composite(
              Image.new("RGBA", result.size),
              result.convert('RGBA')
          )

          result.paste(
            data88,
            (408,710),
            data88
          )
          
      if takim99 != None:
        aldi=True
        try:
          data9=Image.open(f"./Logolar/{takim99}.png")
        except:
          aldi=False
        if aldi:
              data99 = data9.resize((45, 45))
              rgba = data99.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data99,
                  (408,770),
                  data99
              )
          
      if takim100 != None:
        aldi=True
        try:
          data10=Image.open(f"./Logolar/{takim100}.png")
        except:
          aldi=False
        if aldi:
              data100 = data10.resize((45, 45))
              rgba = data100.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data100,
                  (408,832),
                  data100
              )
          
      if takim110 != None:
        aldi=True
        try:
          data111=Image.open(f"./Logolar/{takim110}.png")
        except:
          aldi=False
        if aldi:
              data110 = data111.resize((45, 45))
              rgba = data110.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data110,
                  (1153,296),
                  data110
              )
          
      if takim120 != None:
        aldi=True
        try:
          data12=Image.open(f"./Logolar/{takim120}.png")
        except:
          aldi=False
        if aldi:
              data120 = data12.resize((45, 45))
              rgba = data120.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data120,
                  (1153,358),
                  data120
              )
          
      if takim130 != None:
        aldi=True
        try:
          data13=Image.open(f"./Logolar/{takim130}.png")
        except:
          aldi=False
        if aldi:
              data130 = data13.resize((45, 45))
              rgba = data130.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data130,
                  (1153,416),
                  data130
              )
          
      if takim140 != None:
        aldi=True
        try:
          data14=Image.open(f"./Logolar/{takim140}.png")
        except:
          aldi=False
        if aldi:
              data140 = data14.resize((45, 45))
              rgba = data140.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data140,
                  (1153,476),
                  data140
              )
        
      if takim150 != None:
        aldi=True
        try:
          data15=Image.open(f"./Logolar/{takim150}.png")
        except:
          aldi=False
        if aldi:
              data150 = data15.resize((45, 45))
              rgba = data150.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data150,
                  (1153,535),
                  data150
              )

      if takim160 != None:
        aldi=True
        try:
          data16=Image.open(f"./Logolar/{takim160}.png")
        except:
          aldi=False
        if aldi:
              data160 = data16.resize((45, 45))
              rgba = data160.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data160,
                  (1153,595),
                  data160
              )

      if takim170 != None:
        aldi=True
        try:
          data17=Image.open(f"./Logolar/{takim170}.png")
        except:
          aldi=False
        if aldi:
              data170 = data17.resize((45, 45))
              rgba = data170.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data170,
                  (1153,651),
                  data170
              )

      if takim180 != None:
        aldi=True
        try:
          data18=Image.open(f"./Logolar/{takim180}.png")
        except:
          aldi=False
        if aldi:
              data180 = data18.resize((45, 45))
              rgba = data180.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data180,
                  (1153,710),
                  data180
              )
      
      if takim190 != None:
        aldi=True
        try:
          data19=Image.open(f"./Logolar/{takim190}.png")
        except:
          aldi=False
        if aldi:
              data190 = data19.resize((45, 45))
              rgba = data190.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data190,
                  (1153,770),
                  data190
              )
      
      if takim200 != None:
        aldi=True
        try:
          data20=Image.open(f"./Logolar/{takim200}.png")
        except:
          aldi=False
        if aldi:
              data2000 = data20.resize((45, 45))
              rgba = data2000.convert("RGBA")
              x = result.size[0]//2
              y = result.size[1]//2

              result = Image.alpha_composite(
                  Image.new("RGBA", result.size),
                  result.convert('RGBA')
              )

              result.paste(
                  data2000,
                  (1153,832),
                  data2000
              )

    result.save("./Scrim(test)/Sky Slot 1.png")
    await ctx.send(file=discord.File("./Scrim(test)/Sky Slot 1.png"))
    '''channel = discord.utils.get(self.bot.get_all_channels(), id=channel_id)
      await ctx.send(f"Result Tablosunu {channel.mention} Kanalında Paylaşmanı İster Misin Evet & Hayır?")
      cevap =  await self.bot.wait_for("message",check=checks)
      if cevap.content.lower() == "evet":
        await channel.send(file=discord.File("./Scrim(test)/Pro Slot 1.png"))
      else:
        await ctx.send("Slot Tablosu Paylaşılmadı")'''
  
    
def setup(bot):
  bot.add_cog(Sky_Olustur(bot))