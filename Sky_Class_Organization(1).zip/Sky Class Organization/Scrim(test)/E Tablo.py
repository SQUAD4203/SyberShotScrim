import discord
from discord.ext import commands
import openpyxl
from googleapiclient.discovery import build
from discord.ext import commands
import shutil
import os
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials
import datetime
import sys

class Etablo(commands.Cog):
    def __init__(self,bot):
        self.bot = bot
    
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def emaillist(self,ctx):
        await ctx.send("Bulunduğum Tablolardaki Üyeleri Sıralıyorum.")
        scope = ["https://spreadsheets.google.com/feeds",
         'https://www.googleapis.com/auth/spreadsheets',
         "https://www.googleapis.com/auth/drive.file",
         "https://www.googleapis.com/auth/drive"]
        cred = ServiceAccountCredentials.from_json_keyfile_name("./Scrim(test)/bilgiler.json", scope)
        login = gspread.authorize(cred)
        idss = []
        isims = []

        for spreadsheet in login.openall():
            idss.append(spreadsheet.id)
            
        for spreadsheet in login.openall():
            isims.append(spreadsheet.title)
                    
        drive = build('drive', 'v3',credentials=cred)

                
        perm_id_list = []

        isim_sayisi = 0

        id_sayisi = 0

        isim_degeri1 = len(isims)

        id_degeri1 = len(idss)

        isim_degeri = isim_degeri1 - 1

        id_degeri = id_degeri1 - 1

        while True:
            if id_sayisi <= id_degeri:
                embed=discord.Embed(title=f"**__{isims[isim_sayisi]}__** Tablosu",color=0x4dbbff)
                """await ctx.send(isims[isim_sayisi]+" Tablosunu Düzeltme Yetkisine Sahip Kişileri Sıralıyorum")"""
                perms=drive.permissions().list(fileId=idss[id_sayisi],fields='permissions/emailAddress').execute()
                for p in perms.get("permissions", []):
                    perm_id_list.append(p.get('emailAddress'))
                sayia = 0
                for email in perm_id_list:
                    sayia += 1
                sayib = 0
                for emaill in perm_id_list:
                    while sayib >= 0 and sayib <= sayia:
                        if "iam.gserviceaccount.com" in str(emaill):
                            sayib += 1
                            break
                        else:
                            embed.add_field(name=f"{emaill}", value = "\n\u200b", inline=False)
                            sayib += 1
                            break
                await ctx.send(embed=embed)
                isim_sayisi += 1
                id_sayisi += 1
                perm_id_list.clear()
                continue
            else:
                break
    
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def uyeekle(self,ctx,*,mail=None):
        if mail == None:
            def check(m):
                return m.author.id == ctx.author.id
            await ctx.send("Lütfen Gmail Uzantılı Mail Adresinizi Giriniz")
            mesaj = await self.bot.wait_for("message",check=check)
            mail = str(mesaj.content.lower())
            
        scope = ["https://spreadsheets.google.com/feeds",
                'https://www.googleapis.com/auth/spreadsheets',
                "https://www.googleapis.com/auth/drive.file",
                "https://www.googleapis.com/auth/drive"]
        cred = ServiceAccountCredentials.from_json_keyfile_name("./Scrim(test)/bilgiler.json", scope)
        login = gspread.authorize(cred)

        idler = []
        
        perm_id_list = []
        
        den_list = []
        
        for spreadsheet in login.openall():
                idler.append(spreadsheet.id)
        
        drive = build('drive', 'v3',credentials=cred)

        for ids in idler:
            perm_id_list.clear()
            den_list.clear()
            perms=drive.permissions().list(fileId=ids,fields='permissions/id,permissions/emailAddress').execute()
            for p in perms.get("permissions", []):
                perm_id_list.append([p.get('emailAddress'),p.get('id')])
            for emaill, silinecekk in perm_id_list:
                den_list.append(emaill)
    
            if str(mail) in den_list:
                continue
            else:
                domain_permission = {
                    'type': 'user',
                    'role': 'writer',
                    'emailAddress': str(mail),
                }
                for ids in idler:
                    req = drive.permissions().create(fileId=ids, body=domain_permission, fields="id")
                    req.execute()
                
            await ctx.send("Gmail Adresi Bulunduğum Tüm Tablolara Eklendi")
    
    
    @commands.command()
    @commands.has_permissions(administrator=True)
    async def uyesil(self,ctx,*,mail=None):
        if mail == None:
            def check(m):
                return m.author.id == ctx.author.id
            await ctx.send("Lütfen Silinecek Gmail Uzantılı Mail Adresini Giriniz")
            mesaj = await self.bot.wait_for("message",check=check)
            mail = str(mesaj.content.lower())
            
            
        scope = ["https://spreadsheets.google.com/feeds",
                'https://www.googleapis.com/auth/spreadsheets',
                "https://www.googleapis.com/auth/drive.file",
                "https://www.googleapis.com/auth/drive"]
        cred = ServiceAccountCredentials.from_json_keyfile_name("./Scrim(test)/bilgiler.json", scope)
        login = gspread.authorize(cred)
        
        idler = []
        
        for spreadsheet in login.openall():
            idler.append(spreadsheet.id)
        drive = build('drive', 'v3',credentials=cred)


        perm_id_list = []
        
        den_list = []

        for ids in idler:
            den_list.clear()
            perm_id_list.clear()
            perms=drive.permissions().list(fileId=ids,fields='permissions/id,permissions/emailAddress').execute()
            for p in perms.get("permissions", []):
                perm_id_list.append([p.get('emailAddress'),p.get('id')])
            for emaill, silinecekk in perm_id_list:
                den_list.append(emaill)
            if str(mail) in den_list:
                for email, silinecek in perm_id_list:
                    if email == str(mail):
                        sil=drive.permissions().delete(fileId=ids, permissionId=silinecek, supportsAllDrives = True).execute()
                        await ctx.send("Yazdıdğınız Maili Bulunduğum Tablolardan Erişimi Kaldırdım")
                    else:
                        continue
            else:
                await ctx.send("Girdiğiniz Gmaili Tablolarda Bulamadım Yanlış Girmiş Olabilirsiniz")
                break
            
            

def setup(bot):
    bot.add_cog(Etablo(bot))