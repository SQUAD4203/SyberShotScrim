import discord
import discord.utils
from discord.ext import commands

class Hra(commands.Cog):
  def __init__(self,bot):
    self.bot=bot
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command(aliases=["rb"])
  async def rol_bilgi(self,ctx,role:discord.Role=None):
    if role is None:
        await ctx.send(f"{role.mention} Adında Bir Rol Bulunamadı")
        return
    empty = True
    for member in ctx.guild.members:
        if role in member.roles:
          await ctx.send(f"{role.mention} Rolüne Sahip {member.name}#{member.discriminator} Üyesi Var")
          empty = False
    if empty:
        await ctx.send(f"{role.mention} Rolüne Sahip Üye Bulunamadı")
  
  @commands.has_any_role("Bot Kullanım")
  @commands.command(aliases=["herkestenrolal"])
  async def hra(self,ctx,role:discord.Role):
    role = discord.utils.get(ctx.guild.roles, name=f"{role.name}")
    if role is None:
      await ctx.send(f"{role.mention} Adında Bir Rol Bulunamadı")
      return
    empty = True
    sayi = 0
    for member in ctx.guild.members:
      if role in member.roles:
        await member.remove_roles(role)
        empty = False
        sayi+=1
    await ctx.send(f"{str(sayi)} Kişiden {role.mention} Rolü Alındı")
    if empty:
        await ctx.send(f"{role.mention} Rolüne Sahip Üye Bulunamadı")

  @commands.has_any_role("Bot Kullanım")
  @commands.command()
  async def rolver(self,ctx,role:discord.Role=None,member1:discord.Member=None,member2:discord.Member=None,member3:discord.Member=None,member4:discord.Member=None,member5:discord.Member=None,member6:discord.Member=None,member7:discord.Member=None,member8:discord.Member=None,member9:discord.Member=None,member10:discord.Member=None,member11:discord.Member=None,member12:discord.Member=None,member13:discord.Member=None,member14:discord.Member=None,member15:discord.Member=None,member16:discord.Member=None,member17:discord.Member=None,member18:discord.Member=None,member19:discord.Member=None,member20:discord.Member=None,member21:discord.Member=None,member22:discord.Member=None,member23:discord.Member=None):
    if not role:
      await ctx.send("🇹Verilecek Rol Boş Olamaz")
    
    if not member1:
      await ctx.send("Rol Verilecek Kişi Boş Olamaz")

    isimler1=[member1,member2,member3,member4,member5,member6,member7,member8,member9,member10,member11,member12,member13,member14,member15,member16,member17,member18,member19,member20,member21,member22,member23]

    isimler=[]

    for isim in isimler1:
      if isim != None :
        isimler.append(isim)

    sayi = 0
    list_sayisi=len(isimler)
    list_sayisi2 = int(list_sayisi) - 1

    while int(sayi) < int(list_sayisi):
      """member = discord.utils.get(ctx.guild.members, name=isimler[sayi])"""
      await isimler[sayi].add_roles(role)
      sayi += 1
      
    await ctx.send(f"{list_sayisi} Kişiye Belirttiğiniz Rol Verildi")

  
def setup(bot):
  bot.add_cog(Hra(bot))